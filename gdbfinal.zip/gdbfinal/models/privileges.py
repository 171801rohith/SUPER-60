#Privileges.py

from enum import Enum

class Privilege(Enum):
    PREMIUM = "PREMIUM"
    GOLD = "GOLD"
    SILVER = "SILVER"